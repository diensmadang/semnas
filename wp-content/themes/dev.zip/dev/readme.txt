=== Devfly ===

Contributors: Dcrazed
Devfly Theme, Copyright 2017 Dcrazed

== Description ==

An awesome and free business wordpress theme.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.
4. For step by step guide, check our documentation.

== License ==
Devfly is distributed under the terms of the GNU GPL
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License.
The exceptions to this license are as follows:

* Bootstrap v3.3.6 (http://getbootstrap.com):
    Copyright 2011-2014 Twitter, Inc.
    Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)

* Images:
	All images are from Unsplash (	www.unsplash.com ) .
	License under Creative Commons Zero.
	
* Font Awesome:
	License: SIL OFL 1.1
	URL: http://scripts.sil.org/OFL

* Google Fonts:
	Source Sans Pro (https://www.google.com/fonts/specimen/Source+Sans+Pro)
	License under SIL Open Font License, 1.1
	Copyright © Paul D. Hunt (https://plus.google.com/108888178732927400671/about)

* owl-carousel.js (http://www.owlcarousel.owlgraphic.com/):
	Copyright 2013 Bartosz Wojciechowski
	License under The MIT License (MIT)	

== Frequently Asked Questions ==

= Does this theme support any plugins? =

It includes support for Infinite Scroll in Jetpack.

== Changelog ==

= 1.0 - 09 April 2017 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
